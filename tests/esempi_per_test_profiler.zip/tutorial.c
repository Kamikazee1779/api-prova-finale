#include <stdio.h>
int main(int argc, char* argv[]){
   int a, b;
   (void) scanf("%d %d", &a, &b);

   printf("%d\n",a+b);
   return 0;
}
